package com.android.foodorderapp;

import android.database.sqlite.SQLiteDatabase;

import androidx.appcompat.app.AppCompatActivity;


public class TestDb extends AppCompatActivity {





}
